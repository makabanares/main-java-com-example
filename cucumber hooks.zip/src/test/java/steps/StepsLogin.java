package steps;

import io.cucumber.java.en.*;

public class StepsLogin {

    @Given("the user is on the login page")
    public void userOnLoginPage() {
        System.out.println("User navigates to login page.");
    }

    @When("the user enters valid credentials")
    public void userEntersCredentials() {
        System.out.println("User enters valid credentials.");
    }

    @Then("the user should be redirected to the homepage")
    public void userRedirectedHomepage() {
        System.out.println("User is redirected to homepage.");
    }
}
