package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {

    @Before
    public void setUp() {
        System.out.println("Opening browser before scenario...");
        // WebDriver initialization could go here
    }

    @After
    public void tearDown() {
        System.out.println("Closing browser after scenario...");
        // WebDriver.quit() would go here
    }
}
