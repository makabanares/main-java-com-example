# Proyecto Cucumber Hooks EZTest

## Instrucciones
1. Importar como proyecto Maven en Visual Studio Code o IntelliJ.
2. Ejecutar con:
   ```bash
   mvn test -Dtest=runner.TestRunner
   ```

## Contenido
- `Login.feature`: escenario de login.
- `Hooks.java`: apertura y cierre de navegador centralizado.
- `StepsLogin.java`: steps sin duplicación.
- `TestRunner.java`: ejecuta los escenarios con JUnit.
- `Reporte_Hooks.md`: breve reflexión sobre Hooks.
