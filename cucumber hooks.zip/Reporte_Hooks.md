# Reporte: Utilización de Hooks en Cucumber

El uso de **Hooks** (@Before y @After) permite centralizar la apertura y cierre del navegador,
lo que evita duplicar código en cada Step. Esto mejora la **mantenibilidad** y hace que el
código sea más limpio y fácil de extender en el futuro. También ayuda a que los tests sean más
consistentes, ya que todos los escenarios comparten la misma lógica de preparación y limpieza.
