package smartorders;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({
    CarritoCompraTest.class,
    PedidoServiceTest.class,
    ProductoTest.class,
    CondicionalTest.class
})
public class SuiteCompletaTest {
}