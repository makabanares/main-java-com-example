package smartorders;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class ProductoTest {

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3})
    public void testReducirStock_Valido(int cantidad) {
        Producto p = new Producto("Cable", 5000, 10);
        p.reducirStock(cantidad);
        assertTrue(p.getStock() <= 9);
    }
}