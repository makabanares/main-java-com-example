package smartorders;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assumptions.*;

public class CondicionalTest {

    @Test
    public void testConServicioActivo() {
        boolean servicioActivo = false;
        assumeTrue(servicioActivo, "El servicio no está disponible");
    }
}