package smartorders;

public class PedidoService {

    public double procesarPedido(CarritoCompra carrito) {
        if (carrito.estaVacio()) {
            throw new IllegalArgumentException("El carrito está vacío");
        }

        double total = 0;
        for (Producto producto : carrito.getProductos()) {
            producto.reducirStock(1);
            total += producto.getPrecio();
        }
        return total;
    }
}