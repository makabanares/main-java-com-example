package smartorders;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class CarritoCompraTest {

    private CarritoCompra carrito;
    private Producto producto;

    @BeforeEach
    public void setUp() {
        carrito = new CarritoCompra();
        producto = new Producto("Teclado", 20000, 10);
    }

    @Test
    public void testAgregarProducto() {
        carrito.agregarProducto(producto);
        assertFalse(carrito.estaVacio());
        assertEquals(1, carrito.getProductos().size());
    }
}