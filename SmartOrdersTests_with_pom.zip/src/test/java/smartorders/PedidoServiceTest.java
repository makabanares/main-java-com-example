package smartorders;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class PedidoServiceTest {

    private CarritoCompra carrito;
    private Producto producto;
    private PedidoService pedidoService;

    @BeforeEach
    public void setUp() {
        carrito = new CarritoCompra();
        producto = new Producto("Mouse", 15000, 5);
        pedidoService = new PedidoService();
    }

    @Test
    public void testProcesarPedido_Correcto() {
        carrito.agregarProducto(producto);
        double total = pedidoService.procesarPedido(carrito);
        assertEquals(15000, total);
        assertEquals(4, producto.getStock());
    }

    @Test
    public void testProcesarPedido_CarritoVacio() {
        assertThrows(IllegalArgumentException.class, () -> {
            pedidoService.procesarPedido(carrito);
        });
    }
}