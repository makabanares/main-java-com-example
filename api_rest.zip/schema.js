// Esquema general del recurso Tarea
// Campos mínimos y validaciones base (de alto nivel)

export const TaskSchema = {
  id: { type: "string", format: "uuid", required: true },
  title: { type: "string", minLength: 3, maxLength: 140, required: true },
  description: { type: "string", maxLength: 1000, required: false },
  status: { type: "string", enum: ["pending", "in_progress", "done"], required: true },
  priority: { type: "string", enum: ["low", "medium", "high"], required: false, default: "medium" },
  dueDate: { type: "string", format: "date-time", required: false },
  assigneeId: { type: "string", format: "uuid", required: false },
  createdAt: { type: "string", format: "date-time", required: true },
  updatedAt: { type: "string", format: "date-time", required: true }
};

export const ApiMeta = {
  name: "TechTareas API",
  version: "v1",
  basePath: "/v1",
  resource: "tasks",
  fullBase: "/v1/tasks"
};
