// Contrato de errores de la API (formato consistente)

export const ErrorExample = {
  timestamp: "2025-08-28T10:22:00Z",
  path: "/v1/tasks/123",
  method: "GET",
  status: 404,
  code: "TASK_NOT_FOUND",
  message: "La tarea no existe",
  correlationId: "f6d11554-2a93-4b3a-80d8-f9d2f2aa0fff",
  details: [
    // Ejemplos: { field: "title", issue: "minLength", expected: ">= 3" }
  ]
};

export const ErrorConventions = {
  envelope: "timestamp, path, method, status, code, message, correlationId, details[]",
  idempotency: "Se recomienda header Idempotency-Key para POST",
  rateLimit: "Usar headers X-RateLimit-*"
};
