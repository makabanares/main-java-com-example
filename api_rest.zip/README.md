# Diseño e implementación de una API RESTful — TechTareas

Este paquete contiene los **entregables** del análisis solicitado:

- Esquema general de la API
- Tabla de endpoints con descripciones
- Ejemplos de estructuras JSON (request/response y de error)
- Tabla de códigos de respuesta HTTP
- Justificación de decisiones técnicas
- Archivos en **JavaScript** que exportan los artefactos para su reutilización

> Recurso principal: `tareas` (`/v1/tasks`)

## Estructura del paquete
- `schema.js` — Atributos del recurso y validaciones mínimas
- `endpoints.js` — Endpoints, verbos HTTP y descripción
- `examples.js` — Ejemplos JSON de request/response
- `httpCodes.js` — Códigos de estado HTTP usados y significado
- `errors.js` — Contrato de errores
- `decisions.js` — Justificación técnica

---

© 2025 TechTareas — Propuesta educativa
