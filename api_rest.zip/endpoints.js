// Tabla de endpoints CRUD para /v1/tasks

export const Endpoints = [
  {
    method: "GET",
    path: "/v1/tasks",
    description: "Lista todas las tareas con paginación y filtros opcionales",
    query: {
      page: "number?",
      limit: "number?",
      status: "pending|in_progress|done?",
      assigneeId: "uuid?",
      search: "string?"
    },
    responses: [200]
  },
  {
    method: "POST",
    path: "/v1/tasks",
    description: "Crea una nueva tarea",
    body: ["title*", "description", "status*", "priority", "dueDate", "assigneeId"],
    responses: [201, 400]
  },
  {
    method: "GET",
    path: "/v1/tasks/:id",
    description: "Obtiene una tarea por su ID",
    params: { id: "uuid*" },
    responses: [200, 404]
  },
  {
    method: "PUT",
    path: "/v1/tasks/:id",
    description: "Reemplaza por completo una tarea existente",
    params: { id: "uuid*" },
    body: ["title*", "description", "status*", "priority", "dueDate", "assigneeId"],
    responses: [200, 400, 404]
  },
  {
    method: "PATCH",
    path: "/v1/tasks/:id",
    description: "Actualiza parcialmente una tarea (campos puntuales)",
    params: { id: "uuid*" },
    body: ["title?", "description?", "status?", "priority?", "dueDate?", "assigneeId?"],
    responses: [200, 400, 404]
  },
  {
    method: "DELETE",
    path: "/v1/tasks/:id",
    description: "Elimina una tarea por su ID",
    params: { id: "uuid*" },
    responses: [204, 404]
  }
];
