// Ejemplos de estructuras JSON

export const ExampleCreateRequest = {
  title: "Revisar PR #584",
  description: "Verificar cobertura de pruebas y revisar feedback",
  status: "pending",
  priority: "high",
  dueDate: "2025-09-10T12:00:00Z",
  assigneeId: "9b7a2ed8-3c12-4b5c-8d79-5c4b2f17a111"
};

export const ExampleTaskResponse = {
  id: "e5b8ce86-9440-4c06-9f3f-4f145b5a1c77",
  title: "Revisar PR #584",
  description: "Verificar cobertura de pruebas y revisar feedback",
  status: "pending",
  priority: "high",
  dueDate: "2025-09-10T12:00:00Z",
  assigneeId: "9b7a2ed8-3c12-4b5c-8d79-5c4b2f17a111",
  createdAt: "2025-08-28T10:20:30Z",
  updatedAt: "2025-08-28T10:20:30Z"
};

export const ExampleListResponse = {
  page: 1,
  limit: 20,
  total: 123,
  items: [/* array de tareas (TaskResponse) */]
};
