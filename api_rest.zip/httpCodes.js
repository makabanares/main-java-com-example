// Tabla de códigos HTTP utilizados por la API

export const HttpCodes = [
  { code: 200, meaning: "OK — Operación exitosa" },
  { code: 201, meaning: "Created — Recurso creado" },
  { code: 204, meaning: "No Content — Eliminación o actualización sin cuerpo" },
  { code: 400, meaning: "Bad Request — Datos inválidos" },
  { code: 401, meaning: "Unauthorized — Falta autenticación" },
  { code: 403, meaning: "Forbidden — Sin permisos" },
  { code: 404, meaning: "Not Found — Recurso inexistente" },
  { code: 409, meaning: "Conflict — Regla de negocio/duplicado" },
  { code: 415, meaning: "Unsupported Media Type — Formato no soportado" },
  { code: 422, meaning: "Unprocessable Entity — Validaciones semánticas" },
  { code: 429, meaning: "Too Many Requests — Rate limit excedido" },
  { code: 500, meaning: "Internal Server Error — Error inesperado" }
];
