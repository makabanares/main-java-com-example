// Justificación de decisiones técnicas de la API

export const Decisions = {
  httpMethods: "Se usan métodos HTTP estándar (GET, POST, PUT, PATCH, DELETE) en vez de acciones en la URI para mantener semántica REST, cacheabilidad y compatibilidad con proxies.",
  jsonFormat: "JSON es liviano, ampliamente soportado por web y móvil y fácil de depurar; se recomienda usar camelCase en propiedades.",
  versioning: "Prefijo de versión en la ruta (/v1) para permitir cambios sin romper clientes. De ser posible, acompañar con headers de deprecación.",
  errors: "Contrato de error consistente con código, mensaje y detalles para facilitar troubleshooting.",
  pagination: "Listados paginados con page/limit y total; filtros por status/assigneeId.",
  security: "Autenticación JWT/OAuth2 (Bearer) y autorización por rol; HTTPS obligatorio.",
  docs: "Documentación OpenAPI/Swagger + ejemplos; tests de contrato (e.g., Newman/Rest Assured)."
};
