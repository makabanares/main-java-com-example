
# Reflexión final

La práctica consolidó el uso de **Selenium WebDriver** para manipular elementos HTML de forma confiable. La clave estuvo en **elegir buenos locators** y en comprender los métodos más útiles de `WebElement` (`sendKeys`, `click`, `getText`, `isDisplayed`).

El enfoque de priorizar `id` y `cssSelector` (dejando `xpath` para casos específicos) redujo el costo de mantenimiento. También resultó práctico **WebDriverManager**, que eliminó fricciones por versiones del driver del navegador.

En conjunto, la experiencia refuerza que la automatización debe equilibrar **robustez** (selectores estables, esperas explícitas) y **legibilidad** (código comentado, validaciones claras), siguiendo las buenas prácticas estudiadas en el manual.
