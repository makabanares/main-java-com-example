
# Proyecto: Automatización de elementos web con Selenium (Java + VS Code)

Este proyecto demuestra la **manipulación de elementos HTML** (campos de texto, botones y menús desplegables) con **Selenium WebDriver**, administrando el driver con **WebDriverManager** y ejecutando pruebas con **JUnit 5**.

## Requisitos
- Java 17 (o 11+)
- Maven 3.8+
- Google Chrome instalado
- Visual Studio Code con la extensión *Extension Pack for Java* (o al menos *Language Support for Java by Red Hat*)

## Cómo abrir y ejecutar en Visual Studio Code
1. **Abrir la carpeta** del proyecto en VS Code (`File > Open Folder...`).
2. Aceptar la detección de proyecto Maven si VS Code lo solicita.
3. En una terminal integrada, ejecutar:
   ```bash
   mvn -q -DskipTests=false test
   ```
4. Maven descargará las dependencias y ejecutará las pruebas de JUnit.  
   Por defecto se abrirá Chrome en modo controlado por Selenium.

> Si Chrome se bloquea por política corporativa, puedes cambiar a Firefox reemplazando el `ChromeDriver` por `FirefoxDriver` en el código y agregando el driver correspondiente.

## Estructura
```
pedido-elementos-web-vscode/
├─ pom.xml
├─ README.md
├─ Reporte_Analisis.md
├─ Reflexion.md
└─ src
   └─ test
      └─ java
         └─ com/websolutions/tests/ElementosWebTest.java
```

## Sitios de prueba empleados
- **Login:** https://the-internet.herokuapp.com/login  
- **Dropdown:** https://the-internet.herokuapp.com/dropdown

Ambos son sitios públicos para práctica QA.

## Notas
- El proyecto usa *WebDriverManager* para gestionar automáticamente la versión del driver del navegador.
- Las pruebas están **comentadas paso a paso**, justificando la elección de los *locators*.
