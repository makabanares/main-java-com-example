
package com.websolutions.tests;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.jupiter.api.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

/**
 * Ejemplos de manipulación de elementos web con Selenium WebDriver.
 * - Campo de texto + botón (login con credenciales inválidas)
 * - Menú desplegable (dropdown)
 *
 * Cada paso está comentado y los *locators* se justifican brevemente en el reporte.
 */
public class ElementosWebTest {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeEach
    void setUp() {
        // Configura automáticamente el driver correcto para el navegador.
        WebDriverManager.chromedriver().setup();

        // Opciones de Chrome: deshabilitar mensajes innecesarios.
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");

        driver = new ChromeDriver(options);
        wait   = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit(); // Cierra el navegador al finalizar la prueba.
        }
    }

    @Test
    @DisplayName("Login inválido: campos de texto y botón (verificación de mensaje)")
    void loginInvalidoMuestraMensaje() {
        // 1) Abrir la página de ejemplo (login)
        driver.get("https://the-internet.herokuapp.com/login");

        // 2) Localizar los campos por id (id es único y estable en esta página)
        WebElement username = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));

        // 3) Ingresar credenciales inválidas (sendKeys de WebElement)
        username.sendKeys("usuario_inexistente");
        password.sendKeys("clave_incorrecta");

        // 4) Hacer clic en el botón 'Login' por CSS (selector simple y legible)
        WebElement loginButton = driver.findElement(By.cssSelector("button[type='submit']"));
        loginButton.click();

        // 5) Esperar y validar el mensaje 'flash' por id (texto visible en el DOM)
        WebElement flash = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("flash")));
        String textoFlash = flash.getText();
        Assertions.assertTrue(textoFlash.contains("Your username is invalid!")
                        || textoFlash.contains("Your password is invalid!"),
                "Se esperaba mensaje de credenciales inválidas, pero fue: " + textoFlash);

        // (Opcional) Cerrar el mensaje usando XPath relativo al contenedor #flash
        // WebElement close = flash.findElement(By.xpath(".//a[@class='close']"));
        // close.click();
    }

    @Test
    @DisplayName("Dropdown: seleccionar por texto visible en un <select>")
    void seleccionarEnDropdown() {
        // 1) Abrir la página de dropdown
        driver.get("https://the-internet.herokuapp.com/dropdown");

        // 2) Localizar el <select> por id (id único: 'dropdown')
        WebElement selectElement = driver.findElement(By.id("dropdown"));

        // 3) Usar la clase Select de Selenium para interactuar con menús desplegables
        Select select = new Select(selectElement);
        select.selectByVisibleText("Option 2");

        // 4) Validar que la opción seleccionada sea la esperada
        WebElement option2 = select.getFirstSelectedOption();
        Assertions.assertEquals("Option 2", option2.getText(), "La opción seleccionada no es la esperada.");
    }
}
