
# Reporte de análisis — Manejo de elementos web y elección de *locators*

## 1) Importancia de identificar correctamente los elementos
Una correcta identificación de elementos del DOM asegura que las pruebas sean **estables** y **mantenibles**. Si un localizador es frágil (por ejemplo, un *XPath* muy absoluto o dependiente de posiciones), pequeños cambios en el HTML pueden romper la automatización. Por el contrario, selectores **semánticos y únicos** (como `id` o un `data-testid`) aportan resiliencia.

## 2) WebElement (métodos clave) y estrategias de localización
- **`sendKeys()`**: escribe texto en un *input* o *textarea*.
- **`click()`**: hace clic en enlaces, botones o elementos interactivos.
- **`getText()`**: obtiene el texto visible de un elemento; útil para validar mensajes.
- **`getAttribute(name)`**: recupera atributos para validaciones específicas (p. ej., valor de un input).
- **`isDisplayed()` / `isEnabled()` / `isSelected()`**: verificaciones de estado.

**Estrategias de localización más usadas:**
- `By.id(...)`: preferida cuando el **id es único y estable**.
- `By.cssSelector(...)`: versátil para dirigirse a combinaciones de atributos o estructuras simples (`button[type='submit']`).
- `By.xpath(...)`: potente para situaciones complejas (navegar por jerarquías o texto), aunque conviene evitar *XPaths* frágiles.

## 3) Elección de locators en el script
- **`By.id("username")` y `By.id("password")`** en la página de *Login*: el id es único y expresivo → **estable y semántico**.
- **`By.cssSelector("button[type='submit']")`** para el botón de envío: el tipo de botón es confiable y el selector es corto, legible y robusto.
- **`By.id("flash")`** para capturar el mensaje de resultado: id expresivo y único.
- **`By.id("dropdown")`** para el `<select>` del ejemplo de *Dropdown*: id único y estándar → perfecto para `Select` de Selenium.
- **`By.xpath("//div[@id='flash']/a")`** (opcional) para ubicar el botón de cierre dentro de `#flash` en el ejemplo *Login* cuando se desea interactuar con elementos internos del contenedor.

**Limitaciones y mitigación:**
- Si un **id cambia con frecuencia** (builds dinámicos), preferir `data-testid` o CSS por atributos estables.  
- Evitar XPaths largos basados en índices; mejor atributos únicos o rutas relativas.

## 4) Verificación de resultados
- Se valida el **mensaje flash** tras enviar credenciales inválidas (cambio visible en el DOM).
- En el *dropdown*, se valida la **selección por texto visible**.

## 5) Conclusión del análisis
El uso de *locators* simples, semánticos y únicos (`id`/`css`) combinado con verificaciones claras de estado y texto, disminuye la fragilidad de los tests y facilita su mantenimiento.
