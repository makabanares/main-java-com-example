
package com.example.api;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

public class ReqresApiTest {

    @BeforeAll
    static void setup() {
        RestAssured.baseURI = "https://reqres.in";
    }

    @Test
    void getUsuario_existente_deberiaRetornar200YCampos() {
        given()
        .when()
            .get("/api/users/2")
        .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .time(lessThan(2000L))
            .body("data.id", equalTo(2))
            .body("data.email", containsString("@reqres.in"));
    }

    @Test
    void getUsuario_inexistente_deberiaRetornar404() {
        given()
        .when()
            .get("/api/users/23")
        .then()
            .statusCode(404);
    }

    @Test
    void crearUsuario_deberiaRetornar201YId() {
        String body = """
        {
          "name": "Julio",
          "job": "QA Engineer"
        }
        """;

        given()
            .contentType(ContentType.JSON)
            .body(body)
        .when()
            .post("/api/users")
        .then()
            .statusCode(201)
            .contentType(ContentType.JSON)
            .body("name", equalTo("Julio"))
            .body("job", equalTo("QA Engineer"))
            .body("id", notNullValue());
    }

    @Test
    void actualizarUsuario_put_deberiaRetornar200() {
        String body = """
        {
          "name": "Julio",
          "job": "Senior QA"
        }
        """;

        given()
            .contentType(ContentType.JSON)
            .body(body)
        .when()
            .put("/api/users/2")
        .then()
            .statusCode(200)
            .contentType(ContentType.JSON)
            .body("name", equalTo("Julio"))
            .body("job", equalTo("Senior QA"));
    }

    @Test
    void borrarUsuario_deberiaRetornar204() {
        given()
        .when()
            .delete("/api/users/2")
        .then()
            .statusCode(204);
    }
}
