# api-rest-assured-demo

Proyecto demo con **Rest Assured + JUnit 5** contra `https://reqres.in`.

## Ejecutar tests
```bash
mvn -q -DskipTests=false test
```

## Validaciones
- Códigos HTTP (200, 201, 204, 404)
- Estructura JSON (campos con `body()` y `jsonPath`)
- Headers y tiempo de respuesta
